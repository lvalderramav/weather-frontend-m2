// ARREGLO DE CIUDADES
const tiempo = [
    {
        id: 1,
        localidad: "Santiago Centro",
        temperatura: 25,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 34,
        viento: 14,
        imagen: "https://picsum.photos/id/10/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 18, estado: "Lluvia débil", icono: "fa-cloud-rain" },
            { dia: "Sáb", temp: 24, estado: "Nubes y claros", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 18, estado: "Chubascos", icono: "fa-cloud-showers-heavy" },
            { dia: "Lun", temp: 24, estado: "Despejado", icono: "fa-sun" },
            { dia: "Mar", temp: 26, estado: "Despejado", icono: "fa-sun" },
        ],
    },
    {
        id: 2,
        localidad: "Maipú",
        temperatura: 25,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 35,
        viento: 12,
        imagen: "https://picsum.photos/id/11/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 18, estado: "Lluvia", icono: "fa-cloud-showers-heavy" },
            { dia: "Sáb", temp: 24, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 18, estado: "Chubascos", icono: "fa-cloud-rain" },
            { dia: "Lun", temp: 24, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 26, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 3,
        localidad: "Las Condes",
        temperatura: 23,
        estado: "Parcialmente Nublado",
        icono: "fa-cloud-sun",
        humedad: 38,
        viento: 18,
        imagen: "https://picsum.photos/id/28/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 16, estado: "Lluvia", icono: "fa-cloud-showers-heavy" },
            { dia: "Sáb", temp: 22, estado: "Nublado", icono: "fa-cloud" },
            { dia: "Dom", temp: 15, estado: "Lluvia", icono: "fa-cloud-rain" },
            { dia: "Lun", temp: 22, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Mar", temp: 24, estado: "Despejado", icono: "fa-sun" },
        ],
    },
    {
        id: 4,
        localidad: "Puente Alto",
        temperatura: 24,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 36,
        viento: 15,
        imagen: "https://picsum.photos/id/46/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 17, estado: "Lluvia", icono: "fa-cloud-rain" },
            { dia: "Sáb", temp: 23, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 17, estado: "Chubascos", icono: "fa-cloud-showers-heavy" },
            { dia: "Lun", temp: 23, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 25, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 5,
        localidad: "Quilicura",
        temperatura: 26,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 32,
        viento: 10,
        imagen: "https://picsum.photos/id/54/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 19, estado: "Nublado", icono: "fa-cloud" },
            { dia: "Sáb", temp: 25, estado: "Soleado", icono: "fa-sun" },
            { dia: "Dom", temp: 19, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Lun", temp: 25, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 27, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 6,
        localidad: "La Florida",
        temperatura: 24,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 36,
        viento: 14,
        imagen: "https://picsum.photos/id/103/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 17, estado: "Lluvia débil", icono: "fa-cloud-rain" },
            { dia: "Sáb", temp: 23, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 17, estado: "Chubascos", icono: "fa-cloud-showers-heavy" },
            { dia: "Lun", temp: 23, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 25, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 7,
        localidad: "Pudahuel",
        temperatura: 25,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 33,
        viento: 16,
        imagen: "https://picsum.photos/id/122/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 18, estado: "Lluvia", icono: "fa-cloud-showers-heavy" },
            { dia: "Sáb", temp: 24, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 18, estado: "Chubascos", icono: "fa-cloud-rain" },
            { dia: "Lun", temp: 24, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 26, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 8,
        localidad: "Providencia",
        temperatura: 24,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 35,
        viento: 14,
        imagen: "https://picsum.photos/id/147/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 17, estado: "Lluvia débil", icono: "fa-cloud-rain" },
            { dia: "Sáb", temp: 23, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 17, estado: "Chubascos", icono: "fa-cloud-showers-heavy" },
            { dia: "Lun", temp: 23, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 25, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 9,
        localidad: "San Bernardo",
        temperatura: 24,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 37,
        viento: 12,
        imagen: "https://picsum.photos/id/177/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 17, estado: "Lluvia", icono: "fa-cloud-showers-heavy" },
            { dia: "Sáb", temp: 23, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Dom", temp: 17, estado: "Chubascos", icono: "fa-cloud-rain" },
            { dia: "Lun", temp: 23, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 25, estado: "Soleado", icono: "fa-sun" },
        ],
    },
    {
        id: 10,
        localidad: "Colina",
        temperatura: 27,
        estado: "Despejado",
        icono: "fa-sun",
        humedad: 30,
        viento: 8,
        imagen: "https://picsum.photos/id/184/400/200",
        pronosticoSemanal: [
            { dia: "Vie", temp: 20, estado: "Nublado", icono: "fa-cloud" },
            { dia: "Sáb", temp: 26, estado: "Soleado", icono: "fa-sun" },
            { dia: "Dom", temp: 20, estado: "Parcial", icono: "fa-cloud-sun" },
            { dia: "Lun", temp: 26, estado: "Soleado", icono: "fa-sun" },
            { dia: "Mar", temp: 28, estado: "Soleado", icono: "fa-sun" },
        ],
    },
];
// FIN ARREGLO DE CIUDADES

// DECLARACIÓN DE VARIABLES CON ID's CREADOS EN EL HTML
const headerElement = document.querySelector("header");
const tiempoContainer = document.querySelector("#tiempo-container");
const vistaClima = document.querySelector("#vista-clima");
const vistaDetalle = document.querySelector("#tiempo-detalle"); // Contenedor de la sección detalle
const detalleContenido = document.querySelector("#detalle-container"); // Donde se inyecta el HTML
const btnBack = document.querySelector("#btn-back");
// FIN DECLARACIÓN DE VARIABLES CON ID's CREADOS EN EL HTML

// FUNCIÓN RENDERIZACIÓN DE TARJETAS
function renderCards() {
    let html = "";
    tiempo.forEach((t) => {
        html += `
        <div class="col-12 col-sm-6 col-md-4 mb-4">
            <article class="card card-tiempo h-100" data-id="${t.id}" style="cursor:pointer">
                <img src="${t.imagen}" class="card-img-top object-fit-cover" alt="${t.localidad}" />
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">${t.localidad}</h5>
                    <p class="card-text text-muted">
                        <small>${t.temperatura}°C / ${t.estado}</small>
                    </p>
                    <div class="mt-auto">
                        <i class="fa-solid ${t.icono} text-warning fs-3"></i>
                    </div>
                </div>
            </article>
        </div>`;
    });

    // INSERTA LOS CAMPOS html CREADOS EN EL forEach
    tiempoContainer.innerHTML = html;
}

// FUNCIÓN RENDER DETALLE
function renderDetalle(id) {
    const t = tiempo.find((t) => t.id === id);

    if (!t) return;

    let pronosticoHtml = "";
    t.pronosticoSemanal.forEach((dia) => {
        pronosticoHtml += `
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <span>${dia.dia}</span>
                <i class="fa-solid ${dia.icono}"></i>
                <span>${dia.temp}°C - ${dia.estado}</span>
            </li>`;
    });

    detalleContenido.innerHTML = `
        <div class="row">
            <div class="col-12 col-md-5 mb-4">
                <img src="${t.imagen}" class="img-fluid rounded shadow w-100" alt="${t.localidad}" />
            </div>
            <div class="col-12 col-md-7">
                <h2>${t.localidad}</h2>
                <div class="d-flex flex-wrap gap-2 mb-4">
                    <span class="badge bg-primary">Humedad: ${t.humedad}%</span>
                    <span class="badge bg-info">Viento: ${t.viento} km/h</span>
                    <span class="badge bg-warning text-dark">${t.estado}</span>
                </div>
                <h5>Pronóstico Semanal</h5>
                <ul class="list-group">
                    ${pronosticoHtml}
                </ul>
            </div>
        </div>`;
}

// LOGICA DE NAVEGACIÓN
function mostrarHome() {
    vistaClima.classList.remove("d-none");
    headerElement.classList.remove("d-none");
    vistaDetalle.classList.add("d-none");
}

function mostrarDetalle(id) {
    renderDetalle(id);
    vistaClima.classList.add("d-none");
    headerElement.classList.add("d-none");
    vistaDetalle.classList.remove("d-none");
    window.scrollTo({
        top: 0,
        behavior: "smooth",
    });
}

// EVENTOS
tiempoContainer.addEventListener("click", (e) => {
    const card = e.target.closest(".card-tiempo");
    if (card) {
        mostrarDetalle(Number(card.dataset.id));
    }
});

btnBack.addEventListener("click", mostrarHome);

// INICIALIZACIÓN
renderCards();
// FIN FUNCIÓN RENDERIZACIÓN DE TARJETAS
