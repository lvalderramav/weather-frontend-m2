# 🌦️ **Santiago Weather App**

Una aplicación web moderna y responsive diseñada para consultar el clima en tiempo real de 10 localidades de la Región Metropolitana de Santiago de Chile. Construida con Bootstrap 5 para garantizar una experiencia fluida tanto en dispositivos móviles como en escritorio.

## 🚀 Características Principales

- Dashboard de Localidades: Visualización de 10 zonas mediante Bootstrap Cards que incluyen:
    - Ícono representativo del clima.
    - Temperatura actual.
    - Estado del cielo (Despejado, Nublado, Lluvia, etc.).

- Vista de Detalle: Al seleccionar una localidad, la aplicación navega a una sección extendida con:
- Datos atmosféricos: Humedad y velocidad del viento.
- Pronóstico Semanal: Listado detallado por días de la semana actual.

- Diseño Responsive:
    - Optimizado para móviles (≤ 420px).
    - Diseño extendido para escritorio (≥ 1024px).

## 🛠️ Tecnologías Utilizadas

- HTML5
- CSS3
- JavaScript (ES6+)
- Bootstrap 5 (Framework UI)

## 📋 Requisitos Previos

Para ejecutar este proyecto localmente, asegúrate de tener:

- Un navegador web moderno.
- Conexión a internet

## 🗺️ Localidades Incluidas

- **Norte:** Quilicura, Colina.
- **Centro:** Santiago Centro, Providencia.
- **Oriente:** Las Condes, La Florida.
- **Poniente:** Maipú, Pudahuel.
- **Sur:** Puente Alto, San Bernardo.

### Desarrollado por **Luis Carlos Valderrama Vergara**

Link:
